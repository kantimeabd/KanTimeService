﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KanNotificationService.Models
{
    public class BaseParams
    {
        public int UserId { get; set; }
        public int HHA { get; set; }
    }

    public class iOSNotificationMessage
    {
        public APS aps { get; set; }
        public string type { get; set; }
        public string MessageKey { get; set; }
        public string notificationid { get; set; }
        public string notificationkey { get; set; }
        public DateTime? Timestamp { get; set; }
        public string DeviceToken { get; set; }
        public int NotificationID { get; internal set; }
        public string NotificationKey { get; internal set; }

        public iOSNotificationMessage()
        {
            aps = new APS();
            type = string.Empty;
            MessageKey = string.Empty;

        }
    }

    public class APS
    {
        public alert alert { get; set; }
        public int badge { get; set; }
        public string sound { get; set; }

        [JsonProperty(PropertyName = "content-available")]
        public int content_available { get; set; }

        public APS()
        {
            alert = new alert();
            sound = string.Empty;
        }
    }
    public class alert
    {
        public string title { get; set; }
        public string body { get; set; }

        //UserId
        public string ReceiverID { get; set; }
        //HHA
        public string AgencyID { get; set; }

        public int AppType { get; set; }
        public string NCTitle { get; set; }
        public int EnvType { get; set; }
        public alert()
        {
            title = string.Empty;
            body = string.Empty;
        }
    }
    public class AndoridNotificationMessage
    {
        //public Array registration_ids;
        public notification data { get; set; }
        public AndoridNotificationMessage()
        {
            data = new notification();
        }
    }
    public class notification
    {
        public string title { get; set; }
        public string body { get; set; }
        public string[] registration_ids { get; set; }
        public string type { get; set; }
        public string Sender { get; set; }
        public string key { get; set; }
        public string Timestamp { get; set; }
        public string sound { get; set; }
        public string badge { get; set; }
        public string notificationid { get; set; }
        public string notificationkey { get; set; }
        public string MessageSenderId { get; set; }
        public string NCTitle { get; set; }

        public string ReceiverId { get; set; }
        public string AgencyId { get; set; }

        public int AppType { get; set; }
      
        public int EnvType { get; set; }
        public notification()
        {
            Sender = string.Empty;
            key = string.Empty;
            Timestamp = string.Empty;
        }
    }

    public enum NotificationType
    {
        GCM = 1,
        APNS = 2
    }

    public class DeliveryStatusNotification
    {
        /// <summary>
        /// Pk from the MobileNotifications table
        /// </summary>
        public int NotificationID { get; set; }

        /// <summary>
        /// uniqueidentifier auto generated
        /// </summary>
        public string NotificationKey { get; set; }


        /// <summary>
        /// GCM_APNS_WIN_Token
        /// </summary>
        public string GCM_APNS_WIN_Token { get; set; }

        /// <summary>
        /// Notification is processed sucessfully or not flag
        /// </summary>
        public bool IsSent { get; set; }

        /// <summary>
        /// senton time
        /// </summary>
        public DateTime? SentOn { get; set; }

        /// <summary>
        /// Actually proceesed and succeeded by the notification service
        /// </summary>
        public bool IsDelivered { get; set; }

        /// <summary>
        /// notification succeeded Time
        /// </summary>
        public DateTime? DeliveredOn { get; set; }

        /// <summary>
        /// failure of delivery
        /// </summary>
        public bool IsLastDeliveryFailed { get; set; }

        /// <summary>
        /// increment on every time it fails
        /// </summary>
        public int DeliveryFaildCount { get; set; }

        /// <summary>
        /// increment on very time a notification is sent
        /// </summary>
        public int SentCount { get; set; }

        /// <summary>
        /// IS no longer to be considered
        /// </summary>
        public bool IsExpired { get; set; }

        /// <summary>
        /// expired time
        /// </summary>
        public  DateTime? ExpiredOn { get; set; }
        public string AppToken { get; set; }


    }
    public class DeliveryStatusParams : BaseParams
    {
        public DeliveryStatusNotification NotificationItem { get; set; }
        public NotificationException NotificationExceptionItem { get; set; }
        public DeliveryStatusParams()
        {
            NotificationItem = new DeliveryStatusNotification();
            NotificationExceptionItem = new NotificationException();
        }
        


    }
    public class AddNotificationParams: BaseParams
    {
        public string Authtoken { get; set; }
        public string NotificationType { get; set; }
        public string NotificationSubType { get; set; }
        public string NotificationMessage { get; set; }
        public string NotificationAdditionalText { get; set; }
        public string NotificationExternalId { get; set; }
        public int SenderEmployeeId { get; set; }
        public string SenderEmployeeName { get; set; }

        /// <summary>
        /// ReceiverID¿ReceiverEmployeeNameµReceiverID¿ReceiverEmployeeName => 112¿Samµ113¿Petty
        /// </summary>
        public string ReceiverItems_JSON { get; set; }
        public bool IsGroupNotification { get; set; }
        public DateTime SentOn { get; set; }

    }
    public class UpdateTokenManagerParams : BaseParams
    {
        public string Authtoken { get; set; }
        public int EmployeeId { get; set; }
        public string AppToken { get; set; }
        public string AppType { get; set; }
        public string AppPlatform { get; set; }
        public string GCM_APNS_WIN_Token { get; set; }

    }

    
}