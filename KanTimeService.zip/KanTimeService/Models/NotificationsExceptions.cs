﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KanNotificationService.Models
{
    public class NotificationException
    {
        public int NotificationExceptionId { get; set; }
        public string ExceptionType { get; set; }
        public string ExceptionMessage { get; set; }
        public string ExceptionDesc { get; set; }
      
    }
}