﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KanNotificationService.Models
{
    public class Notification
    {
        /// <summary>
        /// Pk from the MobileNotifications table
        /// </summary>
        public int NotificationID { get; set; }

        /// <summary>
        /// uniqueidentifier auto generated
        /// </summary>
        public string NotificationKey { get; set; }

        /// <summary>
        /// hha
        /// </summary>
       // public int HHA { get; set; }

        /// <summary>
        /// {'MAIL','CHAT','KANTIME'}
        /// </summary>
        /// <returns></returns>
        public string Type { get; set; }

        /// <summary>
        /// { 'Message','Task'}
        /// </summary>
        public string SubType { get; set; }

        /// <summary>
        /// Actual Notification description if more than 1000 char, truncate up to  1000 only.
        /// </summary>
        public string NotificationDesc { get; set; }

        /// <summary>
        /// Referenceid for the actual message
        /// </summary>
        public string ReferenceId { get; set; }

        /// <summary>
        /// caregiverid fk
        /// </summary>
        public int SenderId { get; set; }

        /// <summary>
        /// Name of the sender
        /// </summary>
        /// <returns></returns>
        // public string SenderName { get; set; }

        /// <summary>
        /// NotificationAdditionalText
        /// </summary>
        /// <returns></returns>
        public string NotificationAdditionalText { get; set; }



        /// <summary>
        /// caregiverid fk
        /// </summary>
        public int ReceiverId { get; set; }

        /// <summary>
        /// NotificationGroupId
        /// </summary>
        public int NotificationGroupId { get; set; }

        /// <summary>
        /// Name of the Receiver
        /// </summary>
        /// <returns></returns>
     //   public string ReceiverName { get; set; }

        /// <summary>
        /// AppToken for device identification
        /// </summary>
        public string AppToken { get; set; }

        /// <summary>
        /// GCM_APNS_WIN_Token
        /// </summary>
        public string GCM_APNS_WIN_Token { get; set; }

        /// <summary>
        /// {'Android','iOS','Windows'}
        /// </summary>
        /// <returns></returns>
        public string AppPlatform { get; set; }

        /// <summary>
        /// { 'KI','KM'}
        /// </summary>
        /// <returns></returns>
        public string AppType { get; set; }
       
        public int EnvType { get; set; }

        public string ReceiverName { get; set; }
        public int ReceiverUserId { get; set; }
        /// <summary>
        /// CreatedOn
        /// </summary>
      //  public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Notification is processed sucessfully or not flag
        /// </summary>
     //   public bool IsSent { get; set; }

        /// <summary>
        /// senton time
        /// </summary>
        public DateTime SentOn { get; set; }

        public int ProductId { get; set; }

        public string NCTitle { get; set; }
        // public string NCTitle { get; set; }

        /// <summary>
        /// Actually proceesed and succeeded by the notification service
        /// </summary>
        //public bool IsDelivered { get; set; }

        /// <summary>
        /// notification succeeded Time
        /// </summary>
        //    public DateTime DeliveredOn { get; set; }

        /// <summary>
        /// failure of delivery
        /// </summary>
        //    public bool IsDeliveryFailed { get; set; }

        /// <summary>
        /// increment on every time it fails
        /// </summary>
        //     public int DeliveryFaildCount { get; set; }

        /// <summary>
        /// increment on very time a notification is sent
        /// </summary>
        //     public int SentCount { get; set; }

        /// <summary>
        /// Actual Delivery ack from mobile
        /// </summary>
        //      public bool IsDeliveryAck { get; set; }

        /// <summary>
        /// Actual Delivery ack from mobile
        /// </summary>
        //      public DateTime DeliveryAckOn { get; set; }

        /// <summary>
        /// IS no longer to be considered
        /// </summary>
        //      public bool IsExpired { get; set; }

        /// <summary>
        /// Users.UserId
        /// </summary>
        //      public int CreatedBy { get; set; }

        /// <summary>
        /// expired time
        /// </summary>
        //       public DateTime ExpiredOn { get; set; }

    }


}