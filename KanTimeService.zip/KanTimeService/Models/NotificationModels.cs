﻿using Azure;
using Azure.Core;
using KanNotificationService.Models;
using static Google.Apis.Requests.BatchRequest;
using System.Runtime.Serialization;
using Response = KanNotificationService.Models.Response;

namespace KanTimeService.Models
{
    public class NotificationModels
    {
        [DataContract]
        public class JPushNotificationParams
        {
            [DataMember]
            public int UserId { get; set; }
            [DataMember]
            public int HHA { get; set; }
            [DataMember]
            public string Authtoken { get; set; }
            [DataMember]
            public string NotificationType { get; set; }
            [DataMember]
            public string NotificationSubType { get; set; }
            [DataMember]
            public string NotificationMessage { get; set; }
            [DataMember]
            public string NotificationAdditionalText { get; set; }
            [DataMember]
            public string NotificationExternalId { get; set; }
            [DataMember]
            public int SenderEmployeeId { get; set; }
            [DataMember]
            public string SenderEmployeeName { get; set; }
            [DataMember]
            public List<string> Receivers { get; set; }
            [DataMember]
            public string AppToken { get; set; }
        }

        [DataContract]
        public class JPushNotificationResponse
        {
            [DataMember]
            public int Code { get; set; }
            [DataMember]
            public string Message { get; set; }
        }

        [DataContract]
        public class AddNotificationResponse : Response
        {
            [DataMember]
            public List<Notification> NotificationList { get; set; }
        }

        [DataContract]
        public class JResponse
        {
            public JResponse()
            {
                this.TimeStamp = DateTime.UtcNow.ToString();
            }

            [DataMember]
            public string TimeStamp { get; set; }
            [DataMember]
            public int Code { get; set; }
            [DataMember]
            public string Message { get; set; }
        }

        [DataContract]
        public class JRequest
        {
            /// <summary>
            /// Employeeid
            /// </summary>
            [DataMember]
            public int EmployeeId { get; set; }

            /// <summary>
            /// userid
            /// </summary>
            [DataMember]
            public int UserId { get; set; }

            /// <summary>
            /// Product AuthToken
            /// </summary>
            [DataMember]
            public string Authtoken { get; set; }

            /// <summary>
            /// Company id or HHA id
            /// </summary>
            [DataMember]
            public int HHA { get; set; }
            /// <summary>
            /// App toekn unique token for each user
            /// </summary>
            [DataMember]
            public string AppToken { get; set; }
        }

        [DataContract]
        public class JKNUpdateTokenParams : JRequest
        {

            /// <summary>
            /// Token from mobile app
            /// </summary>
            [IgnoreDataMember]
            public string AppToken { get; set; }

            /// <summary>
            /// Type Of App eg: KMobile/HomeHealth
            /// </summary>
            [DataMember]
            public string AppType { get; set; }

            /// <summary>
            /// Platform
            /// </summary>
            [DataMember]
            public string AppPlatform { get; set; }

            /// <summary>
            /// GCM/APNS token of the device to which notification has to be sent.
            /// </summary>
            [DataMember]
            public string GCM_APNS_WIN_Token { get; set; }

            [DataMember]
            public int Env_Type { get; set; }

        }

        [DataContract]
        public class JKNUpdateTokenResponse : JResponse
        {

        }

        [DataContract]
        public class JKNInActiveUserTokenParams : JRequest
        {

            /// <summary>
            /// Token from mobile app
            /// </summary>
            [DataMember]
            public string AppToken { get; set; }

            /// <summary>
            /// Type Of App eg: KMobile/HomeHealth
            /// </summary>
            [DataMember]
            public string AppType { get; set; }

            /// <summary>
            /// Platform
            /// </summary>
            [DataMember]
            public string AppPlatform { get; set; }

            /// <summary>
            /// GCM/APNS token of the device to which notification has to be sent.
            /// </summary>
            [DataMember]
            public string GCM_APNS_WIN_Token { get; set; }

        }

        [DataContract]
        public class JKNInActiveUserTokenResponse : JResponse
        {

        }
    }
}
