﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace KanNotificationService.Models
{
    [DataContract]
    public class Response
    {
        public Response()
        {
            this.TimeStamp = DateTime.UtcNow.ToString();
        }

        [DataMember]
        public string TimeStamp { get; set; }
        [DataMember]
        public int Code { get; set; }
        [DataMember]
        public string Message { get; set; }
    }

    public class AddNotificationResponse : Response
    {
        public List<Notification> NotificationList { get; set; }
    }
    

    public class GCM_NotificationResponse : Response
    {
        [DataMember]
        public string message_id { get; set; }
        [DataMember]
        public string[] registration_ids { get; set; }
        [DataMember]
        public string to { get; set; }
        [DataMember]
        public string collapse_key { get; set; }
        [DataMember]
        public notification data { get; set; }
        [DataMember]
        public string notification { get; set; }
        [DataMember]
        public string delay_while_idle { get; set; }
        [DataMember]
        public string time_to_live { get; set; }
        [DataMember]
        public string dry_run { get; set; }
        [DataMember]
        public string NotificationKey { get; set; }
        [DataMember]
        public string restricted_package_name { get; set; }
        [DataMember]
        public string content_available { get; set; }
        [DataMember]
        public string priority { get; set; }

    }

    public class APNS_NotificationResponse : Response
    {
        [DataMember]
        public string Tag { get; set; }
        [DataMember]
        public string Identifier { get; set; }
        [DataMember]
        public string DeviceToken { get; set; }
        [DataMember]
        public iOSNotificationMessage Payload { get; set; }
        [DataMember]
        public string Expiration { get; set; }
        [DataMember]
        public string LowPriority { get; set; }
    }
}