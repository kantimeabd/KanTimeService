﻿using FirebaseAdmin;
using FirebaseAdmin.Messaging;
using Google.Apis.Auth.OAuth2;
using KanNotificationService.DAL;
using KanNotificationService.Models;
using KanNotificationService.Utilities;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using static KanTimeService.Models.NotificationModels;

namespace KanTimeService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationController : ControllerBase
    {
        private static bool isFirebaseInitialized = false;

        [HttpPost("SendNotification")]
        public async Task<ActionResult<JPushNotificationResponse>> SendNotification([FromBody] JPushNotificationParams param, [FromHeader(Name = "Authtoken")] string authtoken)
        {
            JPushNotificationResponse response = new JPushNotificationResponse();

            try
            {
                // Retrieve the Authtoken from the headers
                if (string.IsNullOrEmpty(authtoken))
                {
                    return Unauthorized(new { Message = "Missing Authtoken in headers" });
                }

                string apiKey = Environment.GetEnvironmentVariable("API_KEY") ?? string.Empty;
                string senderId = Environment.GetEnvironmentVariable("SENDER_ID") ?? string.Empty;
                string canSendNotification = "1"; //Environment.GetEnvironmentVariable("CAN_SEND_NOTIFICATION") ?? "0";

                if (canSendNotification == "1")
                {
                    using (var manager = new NotificationManager())
                    {
                        var getParams = new AddNotificationParams
                        {
                            UserId = param.UserId,
                            HHA = param.HHA,
                            Authtoken = param.Authtoken,
                            NotificationType = param.NotificationType,
                            NotificationSubType = param.NotificationSubType,
                            NotificationMessage = param.NotificationMessage,
                            NotificationAdditionalText = param.NotificationAdditionalText,
                            NotificationExternalId = param.NotificationExternalId,
                            SenderEmployeeId = param.SenderEmployeeId,
                            SenderEmployeeName = param.SenderEmployeeName,
                            ReceiverItems_JSON = JsonConvert.SerializeObject(param.Receivers),
                            SentOn = DateTime.Now
                        };

                        var notificationResponse = manager.AddNotification(getParams);
                        response.Code = notificationResponse.Code;
                        response.Message = notificationResponse.Message;

                        foreach (var notificationItem in notificationResponse.NotificationList)
                        {
                            param.AppToken = notificationItem.AppToken;

                            if (!string.IsNullOrEmpty(notificationItem.AppPlatform))
                            {
                                var registrationTokens = new List<string> { notificationItem.GCM_APNS_WIN_Token };

                                if (notificationItem.AppPlatform == "Android")
                                {
                                    var androidMessage = new AndoridNotificationMessage
                                    {
                                        data = new notification
                                        {
                                            key = notificationItem.NotificationID.ToString(),
                                            notificationkey = notificationItem.NotificationKey,
                                            Sender = notificationItem.NotificationAdditionalText,
                                            sound = "default",
                                            Timestamp = DateTime.Now.ToString(),
                                            notificationid = notificationItem.NotificationID.ToString(),
                                            type = notificationItem.Type,
                                            MessageSenderId = notificationItem.SenderId.ToString(),
                                            ReceiverId = notificationItem.ReceiverUserId.ToString(),
                                            AgencyId = param.HHA.ToString(),
                                            body = Utils.StripHtmlTags(notificationItem.NotificationDesc).Substring(0, Math.Min(150, Utils.StripHtmlTags(notificationItem.NotificationDesc).Length)),
                                            AppType = notificationItem.ProductId == 1 ? 1 : 2,
                                            EnvType = notificationItem.EnvType
                                        }
                                    };

                                    await AndroidFCMNotification(param, androidMessage, apiKey, registrationTokens, notificationItem.AppType);
                                }
                                else if (notificationItem.AppPlatform == "iOS")
                                {
                                    var iosMessage = new iOSNotificationMessage
                                    {
                                        aps = new APS
                                        {
                                            content_available = 1,
                                            sound = "default",
                                            alert = new alert
                                            {
                                                body = Utils.StripHtmlTags(notificationItem.NotificationDesc).Substring(0, Math.Min(150, Utils.StripHtmlTags(notificationItem.NotificationDesc).Length)),
                                                title = Utils.StripHtmlTags(notificationItem.NCTitle).Substring(0, Math.Min(50, Utils.StripHtmlTags(notificationItem.NCTitle).Length)),
                                            }
                                        },
                                        MessageKey = notificationItem.NotificationID.ToString(),
                                        Timestamp = DateTime.Now,
                                        type = notificationItem.Type,
                                        notificationid = notificationItem.NotificationID.ToString(),
                                        notificationkey = notificationItem.NotificationKey
                                    };

                                    await iOSFCMNotification(param, iosMessage, senderId, registrationTokens, notificationItem.AppType);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.WriteException(ex);
            }

            return Ok(response);
        }

        private async Task AndroidFCMNotification(JPushNotificationParams param, AndoridNotificationMessage message, string serverKey, List<string> registrationTokens, string appType)
        {
            try
            {
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "private_key.json");
                if (!isFirebaseInitialized)
                {
                    FirebaseApp.Create(new AppOptions()
                    {
                        Credential = GoogleCredential.FromFile(filePath)
                    });
                    isFirebaseInitialized = true;
                }

                foreach (var token in registrationTokens)
                {
                    try
                    {
                        string cleanedToken = token.Replace("$1", "");

                        var fcmMessage = new FirebaseAdmin.Messaging.Message()
                        {
                            Token = cleanedToken,
                            Notification = new FirebaseAdmin.Messaging.Notification
                            {
                                Title = message.data.title,
                                Body = message.data.body
                            },
                            Data = new Dictionary<string, string>
                    {
                        { "badge", message.data.badge?.ToString() ?? "0" },
                        { "sender", message.data.Sender },
                        { "notificationid", message.data.notificationid },
                        { "notificationkey", message.data.notificationkey }
                    },
                            Android = new AndroidConfig
                            {
                                Priority = Priority.High
                            }
                        };

                        await FirebaseMessaging.DefaultInstance.SendAsync(fcmMessage);
                    }
                    catch (Exception ex)
                    {
                        Utils.WriteTracking($"Error sending Android notification: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.Write(ex);
            }
        }

        private async Task iOSFCMNotification(JPushNotificationParams param, iOSNotificationMessage message, string senderId, List<string> registrationTokens, string appType)
        {
            try
            {
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "private_key.json");
                if (!isFirebaseInitialized)
                {
                    FirebaseApp.Create(new AppOptions()
                    {
                        Credential = GoogleCredential.FromFile(filePath)
                    });
                    isFirebaseInitialized = true;
                }

                foreach (var token in registrationTokens)
                {
                    try
                    {
                        string cleanedToken = token.Replace("$1", "");

                        var fcmMessage = new FirebaseAdmin.Messaging.Message()
                        {
                            Token = cleanedToken,
                            Apns = new ApnsConfig
                            {
                                Headers = new Dictionary<string, string>
                                {
                                    { "apns-priority", "10" }
                                },
                                Aps = new Aps
                                {
                                    Alert = new ApsAlert
                                    {
                                        Title = message.aps.alert.title,
                                        Body = message.aps.alert.body
                                    },
                                    Badge = 1,
                                    Sound = "default"
                                }
                            }
                        };

                        await FirebaseMessaging.DefaultInstance.SendAsync(fcmMessage);
                    }
                    catch (Exception ex)
                    {
                        Utils.WriteTracking($"Error sending iOS notification: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.Write(ex);
            }
        }
    }
}
