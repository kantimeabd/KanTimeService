﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KanNotificationService.Common
{
    public static class Constants
    {


        public static string ConnectionString = "ConnectionString_DB";

       
        public static string HomeHealth_ExceptionLogFile = "HomeHealth_ExceptionLogFile";
        public static string Hospice_ExceptionLogFile = "Hospice_ExceptionLogFile";

        public static string PushSharpUrl = "https://v3.api.hypertrack.com/";
        public static string apns_cert_key_pwd = "kantime";

        public static string SystemTracking = "SystemTracking";
        public static string ExceptionLogFile = "ExceptionLogFile";
        public static string GCM_Response = "GCM_Response";

        public static string APNS_Response = "APNS_Response";

        public static string Notification_Response = "Notification_Response";
        public static string Notification_Tracking = "Notification_Tracking";
        public static string Notification_ExceptionLogFile = "Notification_ExceptionLogFile";
        public static int Notification_Req_Limit = 1000;
      

    }
}