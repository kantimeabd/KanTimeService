﻿namespace KanTimeService.Common
{
    public interface IConfiguration
    {
        public class MyService
        {
            private readonly IConfiguration _configuration;

            public MyService(IConfiguration configuration)
            {
                _configuration = configuration;
            }

            public string GetConnectionString(string key)
            {
                return _configuration.GetConnectionString(key);
            }
        }
    }
}
