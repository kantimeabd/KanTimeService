﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace KanNotificationService.Utilities
{
    public static class XMLSerializer
    {
        public static string XMLSerialize<T>(T data)
        {
            try
            {
                using (var memoryStream = new MemoryStream())
                {
                    XmlSerializer mySerializer = new XmlSerializer(typeof(T));
                    mySerializer.Serialize(memoryStream, data);

                    memoryStream.Seek(0, SeekOrigin.Begin);

                    var reader = new StreamReader(memoryStream);
                    string content = reader.ReadToEnd();
                    return content;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static T XMLDeSerialize<T>(string xmlString)
        {
            try
            {
                var reader = new StringReader(xmlString);
                var serializer = new XmlSerializer(typeof(T));
                var instance = (T)serializer.Deserialize(reader);

                return instance;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
