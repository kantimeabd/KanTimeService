﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Microsoft.Data.SqlClient;

namespace KanNotificationService.Utilities
{
    /// <summary>
    /// Sql Data Reader Extensions
    /// </summary>
    public static class ReaderExtension
    {

        /// <summary>
        /// To check if column's value is null or not
        /// </summary>
        /// <param name="sdr"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public static bool isDbNull(this SqlDataReader sdr, string param)
        {
            return sdr[param] == DBNull.Value;
        }


        /// <summary>
        /// To check if column exists or not
        /// </summary>
        /// <param name="dataReader"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public static bool isColumnExists(this SqlDataReader dataReader, string param)
        {
            try
            {
                return dataReader.GetOrdinal(param) >= 0;
            }
            catch (IndexOutOfRangeException)
            {
                return false;
            }
        }


        /// <summary>
        /// Converts a given DateTime into a Unix timestamp
        /// </summary>
        /// <param name="value">Any DateTime</param>
        /// <returns>The given DateTime in Unix timestamp format</returns>
        public static long ToUnixTimestamp(this DateTime value)
        {
            return (long)Math.Truncate((value.ToUniversalTime().Subtract(new DateTime(1970, 1, 1))).TotalSeconds);
        }

        /// <summary>
        /// Gets a Unix timestamp representing the current moment
        /// </summary>
        /// <param name="ignored">Parameter ignored</param>
        /// <returns>Now expressed as a Unix timestamp</returns>
        public static long UnixTimestamp(this DateTime ignored)
        {
            return (long)Math.Truncate((DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds);
        }

        /// <summary>
        /// Convert unix timestamp to datetime
        /// </summary>
        /// <param name="unixTimeStamp"></param>
        /// <returns></returns>
        public static DateTime? UnixTimeStampToDateTime(string unixTimeStamp)
        {
            if (string.IsNullOrEmpty(unixTimeStamp))
                return null;

            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(Convert.ToInt64(unixTimeStamp));
            return dtDateTime;
        }
    }
}