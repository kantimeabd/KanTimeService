﻿using HtmlAgilityPack;
using KanNotificationService.Common;
using KanNotificationService.Models;
using System.Configuration;
using System.Data;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using Microsoft.Data.SqlClient;

namespace KanNotificationService.Utilities
{
    public static class Utils
    {
        public static SqlConnectionStringBuilder FormatConnectionString(string Instance, string Server)
        {
            string connectionStirng = String.Empty;

            connectionStirng = System.Configuration.ConfigurationManager.ConnectionStrings[Constants.ConnectionString].ConnectionString;

            SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder(connectionStirng);

            sb["Database"] = Instance;
            sb["Data Source"] = Server;

            return sb;
        }
        /// <summary>
        /// Function to get connection string from web config
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetConnectionStringFromConfig(string key)
        {
            if (System.Configuration.ConfigurationManager.ConnectionStrings[key] != null)
                return System.Configuration.ConfigurationManager.ConnectionStrings[key].ToString();
            else
                return null;
        }
        
        /// <summary>
        /// Function to get Message desc based on errorcode.
        /// </summary>
        /// <param name="errorCode"></param>
        /// <returns></returns>
        public static string GetMessage(int errorCode)
        {
            string message = string.Empty;

            if (errorCode == 1)
                return message;

            try
            {
                string filePath = String.Format("{0}{1}", AppDomain.CurrentDomain.BaseDirectory, "Utilities\\Messages.xml");

                XElement root = XElement.Load(filePath);

                message = (from m in root.Elements("Message")
                           where m.Element("ID").Value.Equals(errorCode.ToString())
                           select m.Element("Description").Value).FirstOrDefault();

                if (string.IsNullOrEmpty(message))
                {
                    message = GetMessage(9999);
                }
            }
            catch (Exception ex)
            {
                Utils.Write(ex);
            }
            return message;
        }

        public static void GetMessage(Response resp, int? Code = null)
        {
            string message = string.Empty;

            if (resp.Code == 1)
                return;

            if (Code != null)
            {
                resp.Code = Code.Value;
            }

            resp.Message = GetMessage(resp.Code);
            resp.TimeStamp = DateTime.UtcNow.ToString();
        }

        /// <summary>
        /// Function to get parameter form web config file.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="configParam"></param>
        /// <returns></returns>
        
        public static T getConfigParam<T>(string configParam)
        {
            T objSession = default(T);
            object configObj = null;

            try
            {
                if (System.Configuration.ConfigurationManager.AppSettings.Get(configParam) != null)
                {
                    configObj = (object)System.Configuration.ConfigurationManager.AppSettings.Get(configParam);
                    if ((System.Type)configObj.GetType() == typeof(T))
                        objSession = (T)(object)System.Configuration.ConfigurationManager.AppSettings.Get(configParam);
                }
            }
            catch (Exception ee)
            {
                IHttpContextAccessor httpContextAccessor = new
                    HttpContextAccessor();
                var userHostAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();

                Utils.Write(0, 0, "Utils",
                     "getConfigParam", "", userHostAddress, ee, "");
            }
            return objSession;
        }
        
        /// <summary>
        /// Function to write excetion to log file.
        /// </summary>
        /// <param name="exp"></param>
        /// 
        public static void Write(Exception exp)
        {
            try
            {

                StringBuilder strbuilder = new StringBuilder();
                strbuilder.Append("************************************************************************************\t");
                strbuilder.Append(string.Format("DATE: {0}", DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt")) + "\t");
                strbuilder.Append(string.Format("Source: {0}", exp.Source) + "\t");
                strbuilder.Append(string.Format("StackTrace: {0}", exp.StackTrace) + "\t");
                strbuilder.Append(string.Format("Data: {0}", exp.Data) + "\t");

                if (null != exp)
                {
                    string _msg = strbuilder.ToString() + "\t" + "Message:" + exp.Message;
                    if (exp.InnerException != null)
                        _msg += " - Inner Exep :" + exp.InnerException.ToString();
                    Utils.Write(_msg);
                }

            }
            catch (Exception ex)
            {
                Utils.Write(ex.ToString());
            }
        }
        
        public static void Write(Exception exp, string Context, int hha, string version)
        {
            try
            {

                StringBuilder strbuilder = new StringBuilder();
                strbuilder.Append("************************************************************************************\t");
                strbuilder.Append(string.Format("DATE: {0}", DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt")) + "\t");
                strbuilder.Append(string.Format("Source: {0}", exp.Source) + "\t");
                strbuilder.Append(string.Format("StackTrace: {0}", exp.StackTrace) + "\t");
                strbuilder.Append(string.Format("Data: {0}", exp.Data) + "\t");

                if (null != exp)
                {
                    string _msg = strbuilder.ToString() + "\t" + "Message:" + exp.Message;
                    if (exp.InnerException != null)
                        _msg += " - Inner Exep :" + exp.InnerException.ToString();
                    Utils.Write(_msg, Context, hha, version);
                }

            }
            catch (Exception ex)
            {
                Utils.Write(ex.ToString(), Context, hha, version);
            }
        }

        public static void Write(string str)
        {
            try
            {
                string fileToWrite = Utils.getConfigParam<string>(Constants.ExceptionLogFile);
                if (null != fileToWrite && fileToWrite != "")
                {
                    //Create the directory if it not exists.
                    string dir = fileToWrite.Substring(0, fileToWrite.LastIndexOf("\\"));
                    if (null != dir)
                    {
                        if (!System.IO.Directory.Exists(dir))
                            System.IO.Directory.CreateDirectory(dir);
                    }
                    StreamWriter sw = new StreamWriter(fileToWrite, true);
                    sw.WriteLine(str);
                    sw.Close();
                }
            }
            catch (Exception)
            {

            }
        }
        /// <summary>
        /// Function to actually write errer to exception file.
        /// </summary>
        /// <param name="str"></param>
        public static void Write(string str, string Context, int hha, string version)
        {
            try
            {

                string ver = string.Empty;

                if (!string.IsNullOrEmpty(version))
                {
                    ver = String.Format(" -- (V {0})", version);
                }

                string fileToWrite = Utils.GetExceptionLogFileName(Context);
                if (null != fileToWrite && fileToWrite != "")
                {

                    if (hha > 0)
                    {
                        string extension = System.IO.Path.GetExtension(fileToWrite);

                        fileToWrite = fileToWrite.Substring(0, fileToWrite.Length - extension.Length);

                        fileToWrite = String.Format("{0}_{1}{2}", fileToWrite, hha, extension);
                    }


                    //Create the directory if it not exists.
                    string dir = fileToWrite.Substring(0, fileToWrite.LastIndexOf("\\"));
                    if (null != dir)
                    {
                        if (!System.IO.Directory.Exists(dir))
                            System.IO.Directory.CreateDirectory(dir);
                    }
                    StreamWriter sw = new StreamWriter(fileToWrite, true);
                    // sw.WriteLine(str);
                    sw.WriteLine(String.Format(@"{0} {1}", str, ver));
                    sw.Close();
                }
            }
            catch (Exception)
            {
                //throw;
            }
        }

        public static void CallTracking(bool WriteInDebugModeOnly, string fileName, string param = "", [CallerMemberName]string memberName = "")
        {
            try
            {
                WriteTracking(string.Format("{0}: {1}   {2} \n", fileName, memberName, param));
            }
            catch { }
        }

        public static void WriteTracking(string str)
        {
            try
            {
                string filename = Constants.Notification_Tracking;

                string fileToWrite = Utils.getConfigParam<string>(filename);

                if (null != fileToWrite && fileToWrite != "")
                {
                    //Create the directory if it not exists.
                    string dir = fileToWrite.Substring(0, fileToWrite.LastIndexOf("\\"));
                    if (null != dir)
                    {
                        if (!System.IO.Directory.Exists(dir))
                            System.IO.Directory.CreateDirectory(dir);
                    }
                    StreamWriter sw = new StreamWriter(fileToWrite, true);

                    var datetime = DateTime.Now.ToString();

                    sw.WriteLine(String.Format(@"{0}:   {1}", datetime, str));
                    sw.Close();
                }
            }
            catch (Exception)
            {

            }
        }

        //public static void WriteTracking(string str, [CallerMemberName]string memberName = "")
        //{
        //    try
        //    {
        //        string ver = string.Empty;

        //        string fileToWrite = Utils.getConfigParam<string>(Constants.SystemTracking);

        //        if (null != fileToWrite && fileToWrite != "")
        //        {

        //            string extension = System.IO.Path.GetExtension(fileToWrite);

        //            fileToWrite = fileToWrite.Substring(0, fileToWrite.Length - extension.Length);

        //            //Create the directory if it not exists.
        //            string dir = fileToWrite.Substring(0, fileToWrite.LastIndexOf("\\"));
        //            if (null != dir)
        //            {
        //                if (!System.IO.Directory.Exists(dir))
        //                    System.IO.Directory.CreateDirectory(dir);
        //            }
        //            StreamWriter sw = new StreamWriter(fileToWrite, true);

        //            var datetime = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt");

        //            sw.WriteLine(String.Format(@"{0}: __ {1}{2}", datetime, str, ver));
        //            sw.Close();
        //        }
        //    }
        //    catch (Exception)
        //    {

        //    }
        //}

        public static void Write(int hha, int user, string fileName, string functionName, string queryString, string clientIP, Exception ex, string Context)
        {
            string fileToWrite = string.Empty;
            string _msg = string.Empty;
            StreamWriter sw = null;
            int writeLogToDataBase = 0;
            try
            {
                //if (!String.IsNullOrEmpty(Utils.getConfigParam<string>("ExceptionLogFile")))
                //    writeLogToDataBase = Convert.ToInt32(Utils.getConfigParam<string>("ExceptionLogFile"));

                if (writeLogToDataBase == 1)
                {
                    //WriteExceptionToDatabase(hha, user, functionName, fileName, queryString, clientIP, ex);
                }
                else
                {
                    fileToWrite = Utils.GetExceptionLogFileName(Context);
                    if (null != ex)
                    {
                        _msg = DateTime.Now.ToString("MMM, d yyyy HH:mm:ss") + "\t" +
                            "hha: " + hha.ToString() + "\t" +
                            "user: " + user.ToString() + "\t" +
                            "fileName: " + fileName + "\t" +
                            "functionName: " + functionName + "\t" +
                            "queryString: " + queryString + "\t" +
                            "clientIP: " + clientIP + "\t" +
                            ex.Message;
                        if (ex.InnerException != null)
                            _msg += "\t - Inner Exep :" + ex.InnerException.ToString();
                    }
                    if (null != fileToWrite && fileToWrite != "")
                    {
                        //Create the directory if it not exists.
                        string dir = fileToWrite.Substring(0, fileToWrite.LastIndexOf("\\"));
                        if (null != dir)
                        {
                            if (!System.IO.Directory.Exists(dir))
                                System.IO.Directory.CreateDirectory(dir);
                        }
                        sw = new StreamWriter(fileToWrite, true);
                        sw.WriteLine(_msg);
                    }
                }
            }
            catch (Exception ee)
            {
                Utils.Write(ee.ToString(), Context, hha, "");
            }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                    sw.Dispose();
                }
            }
        }

        public static string SerializeToXML<T>(T value)
        {
            string serializeXml = "";
            try
            {
                XmlSerializer xmlserializer = new XmlSerializer(typeof(T));
                StringWriter stringWriter = new StringWriter();

                using (XmlWriter writer = XmlWriter.Create(stringWriter))
                {
                    xmlserializer.Serialize(writer, value);
                    serializeXml = stringWriter.ToString();
                }
            }
            catch (Exception ex)
            {
                Utilities.Utils.Write(ex);

            }
            return serializeXml;
        }

        public static DataTable LinqQueryToDataTable<T>(IEnumerable<T> linqQuery)
        {
            DataTable Dt = null;
            Type ObjType = null;
            PropertyInfo[] PropInfo = null;
            try
            {
                Dt = new DataTable();
                ObjType = typeof(T);
                PropInfo = ObjType.GetProperties();
                foreach (PropertyInfo pi in PropInfo)
                {
                    Type pt = pi.PropertyType;
                    //if the incoming datatype is nulll then we need to get the Underlying is datatype
                    //This occures if the filed is a nullable type.
                    if (pt.IsGenericType && pt.GetGenericTypeDefinition() == typeof(Nullable<>))
                        pt = Nullable.GetUnderlyingType(pt);
                    Dt.Columns.Add(pi.Name, pt);
                }
                foreach (T item in linqQuery)
                {
                    DataRow Drw = Dt.NewRow();
                    Drw.BeginEdit();
                    foreach (PropertyInfo pi in PropInfo)
                    {
                        object objval = pi.GetValue(item, null);
                        Drw[pi.Name] = (objval == null ? DBNull.Value : objval);
                    }
                    Drw.EndEdit();
                    Dt.Rows.Add(Drw);
                }
            }
            catch (Exception ee)
            {
                IHttpContextAccessor httpContextAccessor = new HttpContextAccessor();
                var userHostAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();
                Utils.Write(0, 0, "Utils",
                      "LinqQueryToDataTable", "", userHostAddress, ee, "");
            }

            return Dt;
        }
        
        public static string GetExceptionLogFileName(string Context)
        {
            string ExceptionLogFile = Constants.ExceptionLogFile;

            switch (Context)
            {
                case "HH_WEB":
                    ExceptionLogFile = Constants.HomeHealth_ExceptionLogFile;
            break;
                case "HH_MOB":
                    ExceptionLogFile = Constants.HomeHealth_ExceptionLogFile;
            break;
                case "HH_ICE":
                    ExceptionLogFile = Constants.HomeHealth_ExceptionLogFile;
            break;
                case "HOS_WEB":
                    ExceptionLogFile = Constants.Hospice_ExceptionLogFile;
            break;
                case "HOS_MOB":
                    ExceptionLogFile = Constants.Hospice_ExceptionLogFile;
            break;
                case "HOS_ICE":
                    ExceptionLogFile = Constants.Hospice_ExceptionLogFile;
            break;
                default:
                    break;
            }
            return Utils.getConfigParam<string>(ExceptionLogFile);
        }

        //public static int GetUnixDateTime(DateTime datetime)
        //{
        //    var dateTime = new DateTime(datetime.Ticks, DateTimeKind.Utc);
        //    var dateTimeOffset = new DateTimeOffset(datetime);
        //    var unixDateTime = dateTimeOffset.ToUnixTimeSeconds();
        //    return (int)unixDateTime;
        //}

        //public static DateTime GetDateTimeFromUnix(int unixdatetime)
        //{
        //    return DateTimeOffset.FromUnixTimeSeconds(unixdatetime).DateTime.ToLocalTime();
        //}

        public static string StripHtmlTags(string html)
        {
            if (String.IsNullOrEmpty(html)) return "";
            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(html);
            return HtmlEntity.DeEntitize(doc.DocumentNode.InnerText);
        }

        public static void WriteNotificationResponse(string message)
        {
            string filename = Constants.Notification_Response;
            string fileToWrite = Utils.getConfigParam<string>(filename);

            if (null != fileToWrite && fileToWrite != "")
            {
                //Create the directory if it not exists.
                string dir = fileToWrite.Substring(0, fileToWrite.LastIndexOf("\\"));
                if (null != dir)
                {
                    if (!System.IO.Directory.Exists(dir))
                        System.IO.Directory.CreateDirectory(dir);
                }
                StreamWriter sw = new StreamWriter(fileToWrite, true);
                sw.WriteLine(String.Format(@"{0}", message));
                sw.Close();
            }

        }
        
        public static void WriteException(Exception exp)
        {
            //int writeLogToDataBase = 0;
            //int userId = 0;
            //int hhaID = 0;
            try
            {


                StringBuilder strbuilder = new StringBuilder();
                strbuilder.Append("************************************************************************************\t");
                strbuilder.Append(string.Format("DATE: {0}", DateTime.Now.ToString("MMM, d yyyy HH:mm:ss")) + "\t");
                strbuilder.Append(string.Format("Source: {0}", exp.Source) + "\t");
                strbuilder.Append(string.Format("StackTrace: {0}", exp.StackTrace) + "\t");
                strbuilder.Append(string.Format("Data: {0}", exp.Data) + "\t");

                if (null != exp)
                {
                    string _msg = strbuilder.ToString() + "\t" + "Message:" + exp.Message;
                    if (exp.InnerException != null)
                        _msg += " - Inner Exep :" + exp.InnerException.ToString();
                    Utils.WriteException(_msg);
                }

            }
            catch (Exception ex)
            {
                Utils.WriteException(ex.ToString());
            }
        }

        /// <summary>
        /// Function to actually write errer to exception file.
        /// </summary>
        /// <param name="str"></param>
        public static void WriteException(string str)
        {
            try
            {
                string key = Constants.Notification_ExceptionLogFile;
                string fileToWrite = Utils.getConfigParam<string>(key);
                if (null != fileToWrite && fileToWrite != "")
                {
                    //Create the directory if it not exists.
                    string dir = fileToWrite.Substring(0, fileToWrite.LastIndexOf("\\"));
                    if (null != dir)
                    {
                        if (!System.IO.Directory.Exists(dir))
                            System.IO.Directory.CreateDirectory(dir);
                    }
                    StreamWriter sw = new StreamWriter(fileToWrite, true);
                    sw.WriteLine(str);
                    sw.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

}