﻿
using KanNotificationService.Common;
using KanNotificationService.Models;
using KanNotificationService.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using static KanTimeService.Models.NotificationModels;
using AddNotificationResponse = KanTimeService.Models.NotificationModels.AddNotificationResponse;

namespace KanNotificationService.DAL
{
    public interface INotificationManager : IDisposable
    {
        AddNotificationResponse AddNotification(AddNotificationParams Param);
        // GetNotificationToSendResponse GetNotificationsToSend(GetNotificationParams Param);
        Response UpdateDeliveryStatus(DeliveryStatusParams Param);
        JKNUpdateTokenResponse UpdateToken(JKNUpdateTokenParams Param);

        JKNInActiveUserTokenResponse InActiveUserToken(JKNInActiveUserTokenParams Param);
    }

    public class NotificationManager : KanDelegate, INotificationManager
    {
        /// <summary>
        /// 
        /// </summary>
        private bool _isDispose { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public NotificationManager()
        {
            this._isDispose = false;
            string connectionString = Utils.GetConnectionStringFromConfig(Constants.ConnectionString);
            this.SetConnString(connectionString);
        }
        
        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            this.Dispose(this._isDispose);
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isDisposed"></param>
        private void Dispose(bool isDisposed)
        {
            if (!isDisposed)
            {

                this.Disconnect();
                this._isDispose = true;

            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Param"></param>
        /// <returns></returns>
        public JKNUpdateTokenResponse UpdateToken(JKNUpdateTokenParams Param)
        {
            JKNUpdateTokenResponse response = new JKNUpdateTokenResponse();

            try
            {
                string spName = "[dbo].[CreateUpdateToken]";
                this.Connect();
                this.ClearSPParams();
                this.AddSPStringParam("@Authtoken", Param.Authtoken);
                this.AddSPIntParam("@UserID", Param.UserId);
                this.AddSPIntParam("@HHA", Param.HHA);
                this.AddSPIntParam("@EmployeeId", Param.EmployeeId);
                this.AddSPStringParam("@AppToken", Param.AppToken);
                this.AddSPStringParam("@AppType", Param.AppType);
                this.AddSPStringParam("@AppPlatform", Param.AppPlatform == "1" ? "Android" : "iOS");
                this.AddSPStringParam("@GCM_APNS_WIN_Token", Param.GCM_APNS_WIN_Token);
                this.AddSPIntParam("@ENVIRONMENT_TYPE", Param.Env_Type);
                this.AddSPReturnIntParam("@RET_VAL");

                this.ExecuteNonSP(spName);

                response.Code = this.GetOutValueInt("@RET_VAL");

            }
            catch (Exception e)
            {
                Utils.Write(e);
            }
            finally
            {
                this.Disconnect();
            }

            return response;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Param"></param>
        /// <returns></returns>
        public AddNotificationResponse AddNotification(AddNotificationParams Param)
        {
            var response = new AddNotificationResponse();
            bool IsSuccess = false;
            try
            {
                string spName = "[dbo].[AddNotification]";
                this.Connect();
                this.ClearSPParams();
                this.AddSPStringParam("@Authtoken", Param.Authtoken);
                this.AddSPIntParam("@UserID", Param.UserId);
                this.AddSPIntParam("@HHA", Param.HHA);
                this.AddSPStringParam("@NotificationType", Param.NotificationType);
                this.AddSPStringParam("@NotificationSubType", Param.NotificationSubType);
                this.AddSPStringParam("@NotificationMessage", Param.NotificationMessage);
                this.AddSPStringParam("@NotificationAdditionalText", Param.NotificationAdditionalText);
                this.AddSPStringParam("@NotificationExternalId", Param.NotificationExternalId);
                this.AddSPIntParam("@SenderEmployeeId", Param.SenderEmployeeId);
                this.AddSPStringParam("@SenderEmployeeName", Param.SenderEmployeeName);
                this.AddSPStringParam("@ReceiverItems_JSON", Param.ReceiverItems_JSON);
                this.AddSPBoolParam("@IsGroupNotification", Param.IsGroupNotification);
                this.AddSPStringParam("@SentOn", Param.SentOn.ToString("MM/dd/yyyy hh:mm:ss tt"));
                this.AddSPReturnIntParam("@RET_VAL");

                using (Microsoft.Data.SqlClient.SqlDataReader reader = this.ExecuteSelectSP(spName))
                {
                    response.NotificationList = new List<Notification>();

                    while (reader.Read())
                    {
                        var Notification = new Notification();

                        if (!reader.IsDBNull("NotificationID"))
                            Notification.NotificationID = Convert.ToInt32(reader["NotificationID"]);

                        if (!reader.IsDBNull("NotificationKey"))
                            Notification.NotificationKey = Convert.ToString(reader["NotificationKey"]);

                        if (!reader.IsDBNull("Type"))
                            Notification.Type = Convert.ToString(reader["Type"]);

                        if (!reader.IsDBNull("SubType"))
                            Notification.SubType = Convert.ToString(reader["SubType"]);

                        if (!reader.IsDBNull("NotificationDesc"))
                            Notification.NotificationDesc = Convert.ToString(reader["NotificationDesc"]);

                        if (!reader.IsDBNull("ReferenceId"))
                            Notification.ReferenceId = Convert.ToString(reader["ReferenceId"]);

                        if (!reader.IsDBNull("SenderId"))
                            Notification.SenderId = Convert.ToInt32(reader["SenderId"]);

                        if (!reader.IsDBNull("ReceiverId"))
                            Notification.ReceiverId = Convert.ToInt32(reader["ReceiverId"]);

                        if (!reader.IsDBNull("NotificationGroupId"))
                            Notification.NotificationGroupId = Convert.ToInt32(reader["NotificationGroupId"]);

                        if (!reader.IsDBNull("GCM_APNS_WIN_Token"))
                            Notification.GCM_APNS_WIN_Token = Convert.ToString(reader["GCM_APNS_WIN_Token"]);

                        if (!reader.IsDBNull("AppPlatform"))
                            Notification.AppPlatform = Convert.ToString(reader["AppPlatform"]);

                        if (!reader.IsDBNull("AppType"))
                            Notification.AppType = Convert.ToString(reader["AppType"]);

                        if (!reader.IsDBNull("SentOn"))
                            Notification.SentOn = Convert.ToDateTime(reader["SentOn"]);

                        if (!reader.IsDBNull("ProductId"))
                            Notification.ProductId = Convert.ToInt32(reader["ProductId"]);

                        if (!reader.IsDBNull("NotificationTitle"))
                            Notification.NCTitle = Convert.ToString(reader["NotificationTitle"]);

                        if (!reader.IsDBNull("AppToken"))
                            Notification.AppToken = Convert.ToString(reader["AppToken"]);

                        if (!reader.IsDBNull("EnvType"))
                            Notification.EnvType = Convert.ToInt32(reader["EnvType"]);

                        if (!reader.IsDBNull("ReceiverName"))
                            Notification.ReceiverName = Convert.ToString(reader["ReceiverName"]);

                        if (!reader.IsDBNull("ReceiverUserId"))
                            Notification.ReceiverUserId = Convert.ToInt32(reader["ReceiverUserId"]);

                        response.NotificationList.Add(Notification);

                    }
                    reader.Close();
                }
                response.Code = this.GetOutValueInt("@RET_VAL");

                if (this.GetOutValueInt("@RET_VAL") > 0)
                    IsSuccess = true;
            }

            catch (Exception e)
            {
                Utils.Write(e);
            }
            finally
            {
                this.Disconnect();
            }

            return response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Param"></param>
        /// <returns></returns>
        public Response UpdateDeliveryStatus(DeliveryStatusParams Param)
        {
            Response response = new Response();

            try
            {
                string spName = "[dbo].[UpdateDeliveryStatus]";
                this.Connect();
                this.ClearSPParams();
                this.AddSPIntParam("@USER_ID", Param.UserId);
                this.AddSPIntParam("@HHA", Param.HHA);
                this.AddSPIntParam("@NotificationID", Param.NotificationItem.NotificationID);
                this.AddSPStringParam("@NotificationKey", Param.NotificationItem.NotificationKey);
                this.AddSPStringParam("@GCM_APNS_WIN_Token", Param.NotificationItem.GCM_APNS_WIN_Token);
                this.AddSPBoolParam("@IsSent", Param.NotificationItem.IsSent);
                this.AddSPStringParam("@SentOn", Param.NotificationItem.SentOn.ToString());
                this.AddSPBoolParam("@IsDelivered", Param.NotificationItem.IsDelivered);
                this.AddSPStringParam("@DeliveredOn", Param.NotificationItem.DeliveredOn.ToString());
                this.AddSPBoolParam("@IsLastDeliveryFailed", Param.NotificationItem.IsLastDeliveryFailed);
                this.AddSPBoolParam("@IsExpired", Param.NotificationItem.IsExpired);
                this.AddSPStringParam("@ExpiredOn", Param.NotificationItem.ExpiredOn.ToString());
                this.AddSPStringParam("@ExceptionType", Param.NotificationExceptionItem.ExceptionType);
                this.AddSPStringParam("@ExceptionMessage", Param.NotificationExceptionItem.ExceptionMessage);
                this.AddSPStringParam("@ExceptionDesc", Param.NotificationExceptionItem.ExceptionDesc);
                this.AddSPStringParam("@AppToken", Param.NotificationItem.AppToken);

                //this.AddSPIntParam("@NotificationID", ((KanTrackService.Handlers.NotificationItem)Param.NotificationItem).NotificationID);
                //this.AddSPStringParam("@NotificationKey", ((KanTrackService.Handlers.NotificationItem)Param.NotificationItem).NotificationKey);
                //this.AddSPStringParam("@GCM_APNS_WIN_Token", ((KanTrackService.Handlers.NotificationItem)Param.NotificationItem).GCM_APNS_WIN_Token);
                //this.AddSPBoolParam("@IsSent", ((KanTrackService.Handlers.NotificationItem)Param.NotificationItem).IsSent);
                //this.AddSPStringParam("@SentOn", ((KanTrackService.Handlers.NotificationItem)Param.NotificationItem).SentOn.ToString());
                //this.AddSPBoolParam("@IsDelivered", ((KanTrackService.Handlers.NotificationItem)Param.NotificationItem).IsDelivered);
                //this.AddSPStringParam("@DeliveredOn", ((KanTrackService.Handlers.NotificationItem)Param.NotificationItem).DeliveredOn.ToString());
                //this.AddSPBoolParam("@IsLastDeliveryFailed", ((KanTrackService.Handlers.NotificationItem)Param.NotificationItem).IsLastDeliveryFailed);
                //this.AddSPBoolParam("@IsExpired", Param.NotificationItem.IsExpired);
                //this.AddSPStringParam("@ExpiredOn", Param.NotificationItem.ExpiredOn.ToString());
                //this.AddSPStringParam("@ExceptionType", Param.NotificationExceptionItem.ExceptionType);
                //this.AddSPStringParam("@ExceptionMessage", Param.NotificationExceptionItem.ExceptionMessage);
                //this.AddSPStringParam("@ExceptionDesc", Param.NotificationExceptionItem.ExceptionDesc);

                this.AddSPReturnIntParam("@RET_VAL");

                this.ExecuteNonSP(spName);

                response.Code = this.GetOutValueInt("@RET_VAL");

            }
            catch (Exception e)
            {
                Utils.Write(e);
            }
            finally
            {
                this.Disconnect();
            }

            return response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Param"></param>
        /// <returns></returns>
        public JKNInActiveUserTokenResponse InActiveUserToken(JKNInActiveUserTokenParams Param)
        {
            JKNInActiveUserTokenResponse response = new JKNInActiveUserTokenResponse();

            try
            {
                string spName = "[dbo].[InActiveUserToken]";
                this.Connect();
                this.ClearSPParams();
                this.AddSPStringParam("@Authtoken", Param.Authtoken);
                this.AddSPIntParam("@UserID", Param.UserId);
                this.AddSPIntParam("@HHA", Param.HHA);
                this.AddSPIntParam("@EmployeeId", Param.EmployeeId);
                this.AddSPStringParam("@AppToken", Param.AppToken);
                this.AddSPStringParam("@AppType", Param.AppType);
                this.AddSPStringParam("@AppPlatform", Param.AppPlatform == "1" ? "Android" : "iOS");
                // this.AddSPStringParam("@GCM_APNS_WIN_Token", Param.GCM_APNS_WIN_Token);
                this.AddSPReturnIntParam("@RET_VAL");

                this.ExecuteNonSP(spName);

                response.Code = this.GetOutValueInt("@RET_VAL");

            }
            catch (Exception e)
            {
                Utils.Write(e);
            }
            finally
            {
                this.Disconnect();
            }

            return response;
        }
    }
}